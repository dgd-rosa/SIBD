#!/usr/bin/python3
IST_ID = 'ist190105'
host = 'db.tecnico.ulisboa.pt'
port = 5432
password = 'neib7287'
db_name = IST_ID
credentials = 'host=' + host + ' port=' + str(port) + ' user=' + IST_ID + ' password=' + password + ' dbname=' + db_name